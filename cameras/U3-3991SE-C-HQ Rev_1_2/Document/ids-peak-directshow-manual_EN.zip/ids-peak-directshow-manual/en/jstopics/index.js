hmLoadTopic({
hmKeywords:"IDS peak,IDS peak DirectShow,DirectShow,DirectShow video capture filter",
hmTitle:"DirectShow interface in IDS peak",
hmDescription:"DirectShow is part of the Windows Platform SDK from Microsoft and describes a generic (i.e. manufacturer-independent) programming interface for audio and video devices. The...",
hmPrevLink:"about-manual.html",
hmNextLink:"ds-installation-notes.html",
hmParentLink:"index.html",
hmBreadCrumbs:"",
hmTitlePath:"DirectShow interface in IDS peak",
hmHeader:"<h1 class=\"p_Heading1\" style=\"page-break-after: avoid;\"><span class=\"f_Heading1\">DirectShow interface in IDS peak<\/span><\/h1>\n\r",
hmBody:"<p class=\"p_Normal\">DirectShow is part of the Windows Platform SDK from Microsoft and describes a generic (i.e. manufacturer-independent) programming interface for audio and video devices. The DirectShow interface in IDS peak allows you to use a uEye+ camera in DirectShow-based applications. The interface is a DirectShow video capture filter and is based on the transport layer of IDS peak. The interface is introduced for the first time with IDS peak 2.9 under Windows.<\/p>\n\r<p class=\"p_Normal\"><a href=\"ds-installation-notes.html\" class=\"topiclink hmlinklistitem\">Installation<\/a><\/p>\n\r<p class=\"p_Normal\"><a href=\"ds-open-camera.html\" class=\"topiclink hmlinklistitem\">Opening a camera<\/a><\/p>\n\r<p class=\"p_Normal\"><a href=\"ds-notes-usage.html\" class=\"topiclink hmlinklistitem\">Known issues<\/a><\/p>\n\r<p class=\"p_Normal\"><a href=\"ds-camera-settings-via-user-set.html\" class=\"topiclink hmlinklistitem\">Camera settings via UserSet<\/a><\/p>\n\r<div class=\"p_ImageCaption\"><div style=\"margin:1.2500rem 0 0.3125rem 0\"><div style=\"width:100%;max-width:1051px\"><figure style=\"margin:0;padding:0\"><img alt=\"Fig. 1: DirectShow interface in IDS peak\" title=\"Fig. 1: DirectShow interface in IDS peak\" style=\"width:100%;height:auto;border:none\" src=\".\/images\/directshow-ids-peak.svg\"\/><figcaption><p style=\"text-align:center\"><span class=\"f_ImageCaption\">Fig. 1: DirectShow interface in IDS peak<\/span><\/p><\/figcaption><\/figure><\/div><\/div><\/div>\n\r"
})
